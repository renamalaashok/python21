#!/usr/bin/env python
import cgi

form = cgi.FieldStorage()
s=form.getvalue('info')
print "Content-type: text/html"
print 
print "<html><p>{0}</p></html>".format(s)

