import logging
def fun():
	logging.info("Function started")
	return "this is fun in prog1"