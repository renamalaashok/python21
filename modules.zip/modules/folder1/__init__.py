print "__init__"
import f1
import f2