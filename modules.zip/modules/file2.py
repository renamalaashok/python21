print "program started"
def fun():
	return "this is fun in file2"
print fun()
print "other statements in proggram"
print "program ended"