fun()
def fun():
	print "sadfsfsdfsdf"