'''
import file1
print file1.fun(10,20)
'''
'''
import file2
'''
'''
import file3
print __file__
print dir(file3)
print file3.fun()
print file3.main()
'''
import folder1
print folder1.f1.fun()
print folder1.f2.fun()
