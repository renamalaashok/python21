def fun(a,b):
	return a+b
