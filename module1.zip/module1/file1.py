print "program started"
def fun():
	return "this is fun in file1"
print "other statements in program"
print "program ended"