"""
import file1
import sqlite3
con = sqlite3.connect('db1.db')
"""
import mod2
print mod2.f1.fun()
print mod2.f2.fun()
import sqlite3
con = sqlite3.connect('db1.db')
